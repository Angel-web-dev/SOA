package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.PagoModel;
import com.example.demo.service.PagoService;

@RestController
@RequestMapping("/pagos")
public class PagoController {

    @Autowired
    private PagoService pagoService;

    // Obtener todos los pagos
    @GetMapping
    public List<PagoModel> getAllPagos() {
        return pagoService.getAllPagos();
    }

    // Obtener pago por ID
    @GetMapping("/{id}")
    public ResponseEntity<PagoModel> getPagoById(@PathVariable Long id) {
        PagoModel pago = pagoService.getPagoById(id);
        if (pago != null) {
            return ResponseEntity.ok(pago);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    // Crear un nuevo pago
    @PostMapping
    public PagoModel createPago(@RequestBody PagoModel pago) {
        return pagoService.savePago(pago);
    }

    // Actualizar un pago existente
    @PutMapping("/{id}")
    public ResponseEntity<PagoModel> updatePago(@PathVariable Long id, @RequestBody PagoModel pagoDetails) {
        PagoModel pago = pagoService.getPagoById(id);
        if (pago != null) {
            pago.setId_reserva(pagoDetails.getId_reserva());
            pago.setMonto(pagoDetails.getMonto());
            pago.setMetodo_pago(pagoDetails.getMetodo_pago());
            pago.setEstado(pagoDetails.getEstado());
            pago.setFecha_pago(pagoDetails.getFecha_pago());
            PagoModel updatedPago = pagoService.savePago(pago);
            return ResponseEntity.ok(updatedPago);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    // Eliminar un pago
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletePago(@PathVariable Long id) {
        if (pagoService.deletePago(id)) {
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}

