package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.PagoModel;
import com.example.demo.repository.PagoRepository;

@Service
public class PagoService {

    @Autowired
    private PagoRepository pagoRepository;

    // Obtener todos los pagos
    public List<PagoModel> getAllPagos() {
        return pagoRepository.findAll();
    }

    // Obtener un pago por ID
    public PagoModel getPagoById(Long id) {
        return pagoRepository.findById(id).orElse(null);
    }

    // Crear o actualizar un pago
    public PagoModel savePago(PagoModel pago) {
        return pagoRepository.save(pago);
    }

    // Eliminar un pago
    public boolean deletePago(Long id) {
        if (pagoRepository.existsById(id)) {
            pagoRepository.deleteById(id);
            return true;
        }
        return false;
    }
}
