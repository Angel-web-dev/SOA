package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.HabitacionModel;
import com.example.demo.service.HabitacionService;

@RestController
@RequestMapping("/habitaciones")
public class HabitacionController {

    @Autowired
    private HabitacionService habitacionService;

    // Obtener todas las habitaciones
    @GetMapping
    public List<HabitacionModel> getAllHabitaciones() {
        return habitacionService.getAllHabitaciones();
    }

    // Obtener habitación por ID
    @GetMapping("/{id}")
    public ResponseEntity<HabitacionModel> getHabitacionById(@PathVariable Long id) {
        HabitacionModel habitacion = habitacionService.getHabitacionById(id);
        if (habitacion != null) {
            return ResponseEntity.ok(habitacion);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    // Crear una nueva habitación
    @PostMapping
    public HabitacionModel createHabitacion(@RequestBody HabitacionModel habitacion) {
        return habitacionService.saveHabitacion(habitacion);
    }

    // Actualizar una habitación existente
    @PutMapping("/{id}")
    public ResponseEntity<HabitacionModel> updateHabitacion(@PathVariable Long id, @RequestBody HabitacionModel habitacionDetails) {
        HabitacionModel habitacion = habitacionService.getHabitacionById(id);
        if (habitacion != null) {
            habitacion.setNumero(habitacionDetails.getNumero());
            habitacion.setTipo(habitacionDetails.getTipo());
            habitacion.setComodidades(habitacionDetails.getComodidades());
            habitacion.setEstado(habitacionDetails.getEstado());
            HabitacionModel updatedHabitacion = habitacionService.saveHabitacion(habitacion);
            return ResponseEntity.ok(updatedHabitacion);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    // Eliminar una habitación
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteHabitacion(@PathVariable Long id) {
        if (habitacionService.deleteHabitacion(id)) {
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}
