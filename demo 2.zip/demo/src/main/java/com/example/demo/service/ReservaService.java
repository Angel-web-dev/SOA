package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.ReservaModel;
import com.example.demo.repository.ReservaRepository;

@Service
public class ReservaService {

    @Autowired
    private ReservaRepository reservaRepository;

    // Obtener todas las reservas
    public List<ReservaModel> getAllReservas() {
        return reservaRepository.findAll();
    }

    // Obtener una reserva por ID
    public ReservaModel getReservaById(Long id) {
        return reservaRepository.findById(id).orElse(null);
    }

    // Crear o actualizar una reserva
    public ReservaModel saveReserva(ReservaModel reserva) {
        return reservaRepository.save(reserva);
    }

    // Eliminar una reserva por ID
    public boolean deleteReserva(Long id) {
        if (reservaRepository.existsById(id)) {
            reservaRepository.deleteById(id);
            return true;
        }
        return false;
    }
}
