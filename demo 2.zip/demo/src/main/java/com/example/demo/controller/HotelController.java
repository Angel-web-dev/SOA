package com.example.demo.controller;





import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.HotelModel;
import com.example.demo.service.HotelService;

@RestController
@RequestMapping("/hoteles")
public class HotelController {

    @Autowired
    private HotelService hotelService;

    // Obtener todos los hoteles
    @GetMapping
    public List<HotelModel> getAllHoteles() {
        return hotelService.getAllHoteles();
    }

    // Obtener hotel por ID
    @GetMapping("/{id}")
    public HotelModel getHotelById(@PathVariable Long id) {
        return hotelService.getHotelById(id);
    }

    // Crear hotel
    @PostMapping
    public ResponseEntity<HotelModel> saveHotel(@RequestBody HotelModel hotel) {
        return ResponseEntity.ok(hotelService.saveHotel(hotel));
    }

    // Actualizar hotel
    @PutMapping("/{id}")
    public ResponseEntity<HotelModel> updateHotel(@PathVariable Long id, @RequestBody HotelModel datosNuevos) {
        HotelModel actualizado = hotelService.updateHotel(id, datosNuevos);
        if (actualizado != null) {
            return ResponseEntity.ok(actualizado);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    // Eliminar hotel
    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteHotel(@PathVariable Long id) {
        boolean eliminado = hotelService.deleteHotel(id);
        if (eliminado) {
            return ResponseEntity.ok("Hotel eliminado correctamente");
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}