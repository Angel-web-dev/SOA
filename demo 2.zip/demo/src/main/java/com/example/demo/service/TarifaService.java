package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.TarifaModel;
import com.example.demo.repository.TarifaRepository;

@Service
public class TarifaService {

    @Autowired
    private TarifaRepository tarifaRepository;

    // Obtener todas las tarifas
    public List<TarifaModel> getAllTarifas() {
        return tarifaRepository.findAll();
    }

    // Obtener una tarifa por ID
    public TarifaModel getTarifaById(Long id) {
        return tarifaRepository.findById(id).orElse(null);
    }

    // Crear o actualizar una tarifa
    public TarifaModel saveTarifa(TarifaModel tarifa) {
        return tarifaRepository.save(tarifa);
    }

    // Eliminar una tarifa
    public boolean deleteTarifa(Long id) {
        if (tarifaRepository.existsById(id)) {
            tarifaRepository.deleteById(id);
            return true;
        }
        return false;
    }
}
