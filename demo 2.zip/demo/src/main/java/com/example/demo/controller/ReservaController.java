package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.ReservaModel;
import com.example.demo.service.ReservaService;

@RestController
@RequestMapping("/reservas")
public class ReservaController {

    @Autowired
    private ReservaService reservaService;

    // Obtener todas las reservas
    @GetMapping
    public List<ReservaModel> getAllReservas() {
        return reservaService.getAllReservas();
    }

    // Obtener reserva por ID
    @GetMapping("/{id}")
    public ResponseEntity<ReservaModel> getReservaById(@PathVariable Long id) {
        ReservaModel reserva = reservaService.getReservaById(id);
        if (reserva != null) {
            return ResponseEntity.ok(reserva);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    // Crear una nueva reserva
    @PostMapping
    public ReservaModel createReserva(@RequestBody ReservaModel reserva) {
        return reservaService.saveReserva(reserva);
    }

    // Actualizar una reserva existente
    @PutMapping("/{id}")
    public ResponseEntity<ReservaModel> updateReserva(@PathVariable Long id, @RequestBody ReservaModel reservaDetails) {
        ReservaModel reserva = reservaService.getReservaById(id);
        if (reserva != null) {
            reserva.setId_cliente(reservaDetails.getId_cliente());
            reserva.setId_habitacion(reservaDetails.getId_habitacion());
            reserva.setFecha_entrada(reservaDetails.getFecha_entrada());
            reserva.setFecha_salida(reservaDetails.getFecha_salida());
            reserva.setNum_huespedes(reservaDetails.getNum_huespedes());
            reserva.setPrecio_total(reservaDetails.getPrecio_total());
            reserva.setEstado(reservaDetails.getEstado());
            reserva.setCodigo_reserva(reservaDetails.getCodigo_reserva());
            ReservaModel updatedReserva = reservaService.saveReserva(reserva);
            return ResponseEntity.ok(updatedReserva);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    // Eliminar una reserva
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteReserva(@PathVariable Long id) {
        if (reservaService.deleteReserva(id)) {
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}

