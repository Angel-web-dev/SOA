package com.example.demo.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.model.ClienteModel;

@Service
public class ClienteService {

    private final List<ClienteModel> clientes = new ArrayList<>();

    public ClienteService() {
        clientes.add (new ClienteModel("Juan Pérez", "juan@example.com"));
        
        
        clientes.add (new ClienteModel("Lina perez", "lina@example.com"));
        
    }

    // ✅ Obtener todos los clientes
    public List<ClienteModel> getAllClientes() {
        return clientes;
    }

    // ✅ Obtener cliente por ID
    public ClienteModel getClienteById(Long id) {
        return clientes.stream()
                .filter(c -> c.getId().equals(id))
                .findFirst()
                .orElse(null);
    }

    // ✅ Guardar cliente
    public ClienteModel saveCliente(ClienteModel cliente) {
        clientes.add(cliente);
        return cliente;
    }

    // ✅ Eliminar cliente
    public boolean deleteCliente(Long id) {
        return clientes.removeIf(c -> c.getId().equals(id));
    }
}