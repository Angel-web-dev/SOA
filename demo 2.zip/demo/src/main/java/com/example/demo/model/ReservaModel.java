package com.example.demo.model;

import java.time.LocalDate;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "reservas")
public class ReservaModel {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id_reserva;

    private Long id_cliente;
    private Long id_habitacion;
    private LocalDate fecha_entrada;
    private LocalDate fecha_salida;
    private int num_huespedes;
    private double precio_total;
    private String estado;
    private String codigo_reserva;

    // Constructor vacío
    public ReservaModel() {}

    // Constructor con campos
    public ReservaModel(Long id_cliente, Long id_habitacion, LocalDate fecha_entrada, LocalDate fecha_salida,
                        int num_huespedes, double precio_total, String estado, String codigo_reserva) {
        this.id_cliente = id_cliente;
        this.id_habitacion = id_habitacion;
        this.fecha_entrada = fecha_entrada;
        this.fecha_salida = fecha_salida;
        this.num_huespedes = num_huespedes;
        this.precio_total = precio_total;
        this.estado = estado;
        this.codigo_reserva = codigo_reserva;
    }

    // Getters y Setters
    public Long getId_reserva() {
        return id_reserva;
    }

    public void setId_reserva(Long id_reserva) {
        this.id_reserva = id_reserva;
    }

    public Long getId_cliente() {
        return id_cliente;
    }

    public void setId_cliente(Long id_cliente) {
        this.id_cliente = id_cliente;
    }

    public Long getId_habitacion() {
        return id_habitacion;
    }

    public void setId_habitacion(Long id_habitacion) {
        this.id_habitacion = id_habitacion;
    }

    public LocalDate getFecha_entrada() {
        return fecha_entrada;
    }

    public void setFecha_entrada(LocalDate fecha_entrada) {
        this.fecha_entrada = fecha_entrada;
    }

    public LocalDate getFecha_salida() {
        return fecha_salida;
    }

    public void setFecha_salida(LocalDate fecha_salida) {
        this.fecha_salida = fecha_salida;
    }

    public int getNum_huespedes() {
        return num_huespedes;
    }

    public void setNum_huespedes(int num_huespedes) {
        this.num_huespedes = num_huespedes;
    }

    public double getPrecio_total() {
        return precio_total;
    }

    public void setPrecio_total(double precio_total) {
        this.precio_total = precio_total;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getCodigo_reserva() {
        return codigo_reserva;
    }

    public void setCodigo_reserva(String codigo_reserva) {
        this.codigo_reserva = codigo_reserva;
    }
}

