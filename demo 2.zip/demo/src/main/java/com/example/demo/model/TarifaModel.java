package com.example.demo.model;

import java.time.LocalDate;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "tarifas")
public class TarifaModel {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id_tarifa;

    private Long id_habitacion;
    private LocalDate fecha;
    private double precio;
    private String tipo_tarifa;

    // Constructor vacío
    public TarifaModel() {}

    // Constructor con campos
    public TarifaModel(Long id_habitacion, LocalDate fecha, double precio, String tipo_tarifa) {
        this.id_habitacion = id_habitacion;
        this.fecha = fecha;
        this.precio = precio;
        this.tipo_tarifa = tipo_tarifa;
    }

    // Getters y Setters
    public Long getId_tarifa() {
        return id_tarifa;
    }

    public void setId_tarifa(Long id_tarifa) {
        this.id_tarifa = id_tarifa;
    }

    public Long getId_habitacion() {
        return id_habitacion;
    }

    public void setId_habitacion(Long id_habitacion) {
        this.id_habitacion = id_habitacion;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public String getTipo_tarifa() {
        return tipo_tarifa;
    }

    public void setTipo_tarifa(String tipo_tarifa) {
        this.tipo_tarifa = tipo_tarifa;
    }
}

