package com.example.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.model.PropiedadModel;

@Repository
public interface PropiedadRepository extends JpaRepository<PropiedadModel, Long> {

    List<PropiedadModel> findByCiudad(String ciudad);
    List<PropiedadModel> findByPais(String pais);
    List<PropiedadModel> findByTipo(String tipo);
    List<PropiedadModel> findByPrecioBetween(Double min, Double max);
    List<PropiedadModel> findByNumHabitaciones(Integer numHabitaciones);

   
    // 🔹 ESTE ES EL MÉTODO QUE NECESITAS:
    List<PropiedadModel> findByIdPropietario(Long idPropietario);
}

