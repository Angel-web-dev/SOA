package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.HabitacionModel;
import com.example.demo.repository.HabitacionRepository;

@Service
public class HabitacionService {

    @Autowired
    private HabitacionRepository habitacionRepository;

    // Obtener todas las habitaciones
    public List<HabitacionModel> getAllHabitaciones() {
        return habitacionRepository.findAll();
    }

    // Obtener una habitación por ID
    public HabitacionModel getHabitacionById(Long id) {
        return habitacionRepository.findById(id).orElse(null);
    }

    // Crear o actualizar una habitación
    public HabitacionModel saveHabitacion(HabitacionModel habitacion) {
        return habitacionRepository.save(habitacion);
    }

    // Eliminar una habitación por ID
    public boolean deleteHabitacion(Long id) {
        if (habitacionRepository.existsById(id)) {
            habitacionRepository.deleteById(id);
            return true;
        }
        return false;
    }
}
