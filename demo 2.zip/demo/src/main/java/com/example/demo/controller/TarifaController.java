package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.TarifaModel;
import com.example.demo.service.TarifaService;

@RestController
@RequestMapping("/tarifas")
public class TarifaController {

    @Autowired
    private TarifaService tarifaService;

    // Obtener todas las tarifas
    @GetMapping
    public List<TarifaModel> getAllTarifas() {
        return tarifaService.getAllTarifas();
    }

    // Obtener tarifa por ID
    @GetMapping("/{id}")
    public ResponseEntity<TarifaModel> getTarifaById(@PathVariable Long id) {
        TarifaModel tarifa = tarifaService.getTarifaById(id);
        if (tarifa != null) {
            return ResponseEntity.ok(tarifa);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    // Crear una nueva tarifa
    @PostMapping
    public TarifaModel createTarifa(@RequestBody TarifaModel tarifa) {
        return tarifaService.saveTarifa(tarifa);
    }

    // Actualizar una tarifa existente
    @PutMapping("/{id}")
    public ResponseEntity<TarifaModel> updateTarifa(@PathVariable Long id, @RequestBody TarifaModel tarifaDetails) {
        TarifaModel tarifa = tarifaService.getTarifaById(id);
        if (tarifa != null) {
            tarifa.setId_habitacion(tarifaDetails.getId_habitacion());
            tarifa.setFecha(tarifaDetails.getFecha());
            tarifa.setPrecio(tarifaDetails.getPrecio());
            tarifa.setTipo_tarifa(tarifaDetails.getTipo_tarifa());
            TarifaModel updatedTarifa = tarifaService.saveTarifa(tarifa);
            return ResponseEntity.ok(updatedTarifa);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    // Eliminar una tarifa
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteTarifa(@PathVariable Long id) {
        if (tarifaService.deleteTarifa(id)) {
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}

