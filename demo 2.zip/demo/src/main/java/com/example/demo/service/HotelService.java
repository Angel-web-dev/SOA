package com.example.demo.service;

import com.example.demo.model.HotelModel;
import com.example.demo.repository.HotelRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class HotelService {

    @Autowired
    private HotelRepository hotelRepository;

    public List<HotelModel> getAllHoteles() {
        return hotelRepository.findAll();
    }

    public HotelModel getHotelById(Long id) {
        return hotelRepository.findById(id).orElse(null);
    }

    public HotelModel saveHotel(HotelModel hotel) {
        return hotelRepository.save(hotel);
    }

    public HotelModel updateHotel(Long id, HotelModel datosNuevos) {
        Optional<HotelModel> hotelExistente = hotelRepository.findById(id);
        if (hotelExistente.isPresent()) {
            HotelModel h = hotelExistente.get();
            h.setNombre(datosNuevos.getNombre());
            h.setDireccion(datosNuevos.getDireccion());
            h.setEstrellas(datosNuevos.getEstrellas());
            h.setPrecioPorNoche(datosNuevos.getPrecioPorNoche());
            return hotelRepository.save(h);
        }
        return null;
    }

    public boolean deleteHotel(Long id) {
        if (hotelRepository.existsById(id)) {
            hotelRepository.deleteById(id);
            return true;
        }
        return false;
    }
}