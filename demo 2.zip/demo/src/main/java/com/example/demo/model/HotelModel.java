package com.example.demo.model;

import jakarta.persistence.*;

@Entity
@Table(name = "hoteles")
public class HotelModel {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String nombre;
    private String direccion;
    private int estrellas;
    private double precioPorNoche;

    // Constructor vacío
    public HotelModel() {}

    // Constructor con parámetros
    public HotelModel(String nombre, String direccion, int estrellas, double precioPorNoche) {
        this.nombre = nombre;
        this.direccion = direccion;
        this.estrellas = estrellas;
        this.precioPorNoche = precioPorNoche;
    }

    // Getters y Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getDireccion() { return direccion; }
    public void setDireccion(String direccion) { this.direccion = direccion; }

    public int getEstrellas() { return estrellas; }
    public void setEstrellas(int estrellas) { this.estrellas = estrellas; }

    public double getPrecioPorNoche() { return precioPorNoche; }
    public void setPrecioPorNoche(double precioPorNoche) { this.precioPorNoche = precioPorNoche; }
}