package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.PropiedadModel;
import com.example.demo.repository.PropiedadRepository;

@Service
public class PropiedadService {

    @Autowired
    private PropiedadRepository propiedadRepository;

    // Obtener todas las propiedades
    public List<PropiedadModel> getAllPropiedades() {
        return propiedadRepository.findAll();
    }

    // Obtener propiedad por ID
    public Optional<PropiedadModel> getPropiedadById(Long id) {
        return propiedadRepository.findById(id);
    }

    // Guardar o actualizar propiedad
    public PropiedadModel savePropiedad(PropiedadModel propiedad) {
        return propiedadRepository.save(propiedad);
    }

    // Eliminar propiedad
    public void deletePropiedad(Long id) {
        propiedadRepository.deleteById(id);
    }

    // Buscar propiedades por ciudad
    public List<PropiedadModel> findByCiudad(String ciudad) {
        if (ciudad == null || ciudad.trim().isEmpty()) {
            throw new IllegalArgumentException("La ciudad no puede ser nula o vacía");
        }

        String ciudadFormateada = ciudad.substring(0, 1).toUpperCase() + ciudad.substring(1).toLowerCase();

        List<PropiedadModel> propiedades = propiedadRepository.findByCiudad(ciudadFormateada);

        System.out.println("Se encontraron " + propiedades.size() + " propiedades en la ciudad: " + ciudadFormateada);

        return propiedades;
    }

    // Buscar propiedades por país
    public List<PropiedadModel> findByPais(String pais) {
        return propiedadRepository.findByPais(pais);
    }

    // 🔹 19. Recuperar propiedades por tipo
    public List<PropiedadModel> findByTipo(String tipo) {
        if (tipo == null || tipo.trim().isEmpty()) {
            throw new IllegalArgumentException("El tipo no puede ser nulo o vacío");
        }
        return propiedadRepository.findByTipo(tipo);
    }

    // 🔹 20. Recuperar propiedades por rango de precio
    public List<PropiedadModel> findByPrecioBetween(Double precioMin, Double precioMax) {
        if (precioMin == null || precioMax == null || precioMin < 0 || precioMax < 0) {
            throw new IllegalArgumentException("Los precios no pueden ser nulos o negativos");
        }
        return propiedadRepository.findByPrecioBetween(precioMin, precioMax);
    }

    // 🔹 21. Recuperar propiedades por número de habitaciones
    public List<PropiedadModel> findByNumHabitaciones(Integer numHabitaciones) {
        if (numHabitaciones == null || numHabitaciones < 0) {
            throw new IllegalArgumentException("El número de habitaciones no puede ser nulo ni negativo");
        }
        return propiedadRepository.findByNumHabitaciones(numHabitaciones);
    }

    // 🔹 23. Recuperar todas las propiedades de un propietario
    public List<PropiedadModel> findByIdPropietario(Long idPropietario) {
        if (idPropietario == null) {
            throw new IllegalArgumentException("El ID del propietario no puede ser nulo");
        }
        return propiedadRepository.findByIdPropietario(idPropietario);
    }

}

